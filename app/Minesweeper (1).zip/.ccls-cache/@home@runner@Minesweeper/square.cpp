#include <string>
using namespace std;

class Square {

int x, y;

//if(griddy[choicex][choicey]==m){
//gameOver
//} else if(griddy[choicex][choicey]==9) {}
//square();
};