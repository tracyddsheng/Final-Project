#inclfor (int i = width * height; i > 0; i--) {
    outyput += griddy[int(floor((i - 1) / width))][int((i - 1) - floor((i - 1) / width))];
    if (i % width == 1) {
      outyput += "\n";
    }