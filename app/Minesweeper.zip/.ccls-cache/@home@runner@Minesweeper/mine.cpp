using namespace std;

class Mine {
  int x, y, totalMineCount;
  bool trig; // is it triggered
};