class Grid{
  public:
    int width;
    int height;

    char griddy[width][height];

}